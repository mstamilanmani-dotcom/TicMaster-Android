#!/usr/bin/env bash
set -euo pipefail

# Install Android command-line SDK into the Codespace home directory
SDK_ROOT="$HOME/android-sdk"
TOOLS="$SDK_ROOT/cmdline-tools/latest"
mkdir -p "$SDK_ROOT/cmdline-tools"

if [ ! -x "$TOOLS/bin/sdkmanager" ]; then
  cd /tmp
  curl -L "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o android-cli.zip
  mkdir -p android-cli
  unzip -q -o android-cli.zip -d android-cli
  mkdir -p "$TOOLS"
  cp -r android-cli/cmdline-tools/* "$TOOLS/"
fi

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$TOOLS/bin:$SDK_ROOT/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

# Install Gradle 8.9 if not already available
if ! command -v gradle >/dev/null 2>&1; then
  cd /tmp
  curl -L "https://services.gradle.org/distributions/gradle-8.9-bin.zip" -o gradle-8.9-bin.zip
  unzip -q -o gradle-8.9-bin.zip
  export PATH="/tmp/gradle-8.9/bin:$PATH"
fi

cd "$(dirname "$0")"
gradle --no-daemon assembleDebug

echo
echo "APK created at:"
echo "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
