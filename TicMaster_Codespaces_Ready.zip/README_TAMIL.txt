TicMaster Android App - Android Studio Project

இந்த project-ல் TicMaster game local HTML asset-ஆக Android WebView-ல் இயங்கும்.
Game content phone-க்குள் bundled; internet இல்லாமலும் game logic இயங்கும்.
Google font இணையம் கிடைத்தால் load ஆகலாம்; இல்லையெனில் system font fallback ஆகும்.

APK build செய்ய:
1. ZIP extract செய்யவும்.
2. Android Studio install/open செய்யவும்.
3. Open -> extract செய்த TicMaster_Android folder select செய்யவும்.
4. Gradle sync முடியும் வரை காத்திருக்கவும்.
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. app/build/outputs/apk/debug/app-debug.apk கிடைக்கும்.
7. APK-ஐ Android phone-க்கு copy செய்து install செய்யவும்.
   Unknown apps install permission கேட்டால் Android Settings-ல் அனுமதி கொடுக்கவும்.

Package: com.manims.ticmaster
Minimum Android: Android 8.0 (API 26)
Version: 1.0

Note: APK build செய்ய Android Studio + Android SDK தேவை. இந்த ZIP complete source project;
prebuilt APK அல்ல.
