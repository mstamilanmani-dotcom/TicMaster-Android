TicMaster Android - Codespaces mobile build

Phone-only workflow:
1) Upload this ZIP to a GitHub repository (or extract and upload its files).
2) Open the repository -> Code -> Codespaces -> Create codespace.
3) Open Terminal in the Codespace.
4) If uploaded as ZIP inside the repo, extract it first and cd into the project folder.
5) Run:
   chmod +x build-apk.sh
   ./build-apk.sh
   First setup downloads Android SDK and Gradle; may take several minutes.
6) APK:
   app/build/outputs/apk/debug/app-debug.apk

Download APK from Codespaces Explorer:
- Open app/build/outputs/apk/debug
- Tap/right-click app-debug.apk -> Download
- On Android, open Downloads -> app-debug.apk -> Install

Note:
- Codespaces browser is cloud Linux; it does not run Android emulator in the phone browser.
- This builds the installable APK in cloud; install and test it on your Android phone.
- Android SDK setup requires network access and enough Codespaces quota.
